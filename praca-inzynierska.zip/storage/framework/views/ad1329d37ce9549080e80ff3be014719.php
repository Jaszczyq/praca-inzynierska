<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-end mb-3">

            <div class="col-auto">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('organizer')): ?>
                    <a href="<?php echo e(route('events.create')); ?>" class="btn btn-primary">Dodaj wydarzenie</a>
                <?php endif; ?>
            </div>

        </div>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="col-auto">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('organizer')): ?>
                        <a href="<?php echo e(route('events.create')); ?>" class="btn btn-primary">Dodaj wydarzenie</a>
                        <?php endif; ?>
                    </div>
                    <div class="card-header">


                        <div class="btn-group">
                            <a href="<?php echo e(route('events.index', ['date' => $selectedDate->copy()->subDays(min(7, now()->subDay()->diffInDays($selectedDate)))->format('Y-m-d')])); ?>" class="btn btn-secondary">
                                &lt;
                            </a>
                            <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('events.index', ['date' => $date->format('Y-m-d')])); ?>" class="btn btn-secondary">
                                    <?php echo e($date->format('d.m')); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('events.index', ['date' => $selectedDate->copy()->addDays(7)->format('Y-m-d')])); ?>" class="btn btn-secondary">
                                &gt;
                            </a>
                        </div>
                    </div>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                        <?php echo e(__('Logout')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                    <div class="card-body">
                        <h5><?php echo e($selectedDate->format('d.m.Y')); ?></h5>
                        <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="card mb-3">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($event->title); ?></h5>
                                    <p class="card-text"><?php echo e($event->description); ?></p>
                                    <p class="card-text"><small class="text-muted"><?php echo e($event->date->format('H:i')); ?></small></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>Brak wydarzeń na ten dzień.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var selectedDate = new Date("<?php echo e($selectedDate->format('Y-m-d')); ?>");

            function updateUrl(date) {
                var formattedDate = formatDate(date);
                var url = "<?php echo e(route('events.index')); ?>" + "?date=" + formattedDate;
                window.location.href = url;
            }

            function formatDate(date) {
                var year = date.getFullYear();
                var month = ('0' + (date.getMonth() + 1)).slice(-2);
                var day = ('0' + date.getDate()).slice(-2);
                return year + '-' + month + '-' + day;
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/programme/index.blade.php ENDPATH**/ ?>
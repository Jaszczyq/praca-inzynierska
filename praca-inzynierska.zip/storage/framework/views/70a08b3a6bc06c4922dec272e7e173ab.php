<?php $__env->startSection('content'); ?>

    <div class="container">

        <div class="row justify-content-end mb-3">

            <div class="col-auto">

                <a href="<?php echo e(route('events.create')); ?>" class="btn btn-primary">Dodaj wydarzenie</a>

            </div>

        </div>

        <div class="row flex-wrap">

            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-md-6 mb-4">

                    <div class="card h-100">

                        <img src="<?php echo e(config('filesystems.disks.local.root')); ?>/<?php echo e($event['image']); ?>" alt="Event Image" class="card-img-top">

                        <div class="card-body">

                            <h5 class="card-title"><?php echo e($event['title']); ?></h5>

                            <p class="card-text"><?php echo e($event['description']); ?></p>

                            <p class="card-text"><small class="text-muted"><?php echo e($event['date']); ?> <?php echo e($event['time'] ?? ''); ?></small></p>
                            <div class="d-flex justify-content-between">

                                <a href="<?php echo e(route('events.show', ['event' => $event['id']])); ?>" class="btn btn-info mr-2">Szczegóły</a>

                            </div>

                        </div>

                    </div>

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/events/index.blade.php ENDPATH**/ ?>